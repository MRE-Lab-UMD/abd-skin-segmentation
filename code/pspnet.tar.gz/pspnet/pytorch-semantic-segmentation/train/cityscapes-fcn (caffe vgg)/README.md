# Results

## Metrics
train only on cityscapes fine, training batch size: 12, iter num per epoch: 248, lr: 1e-10, sum the pixel loss
![](static/fcn8s-train_loss.jpg)

validate the loss and mean_iu after training of one epoch
![](static/fcn8s-val_loss.jpg)

![](static/fcn8s-mean_iu.jpg)

## Visualization
![](static/fcn8s-epoch328.jpg)
