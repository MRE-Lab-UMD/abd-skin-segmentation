from .duc_hdc import *
from .fcn16s import *
from .fcn32s import *
from .fcn8s import *
from .gcn import *
from .psp_net import *
from .seg_net import *
from .u_net import *
